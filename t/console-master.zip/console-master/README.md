# console.js

a console panel for mobile phone, replace alert

Preview
-------

###close status
<div align="center">
    <img src="images/close.png" />
</div>

###open status
<div align="center">
    <img src="images/open.png" />
</div>

### Building

``` bash
npm run build
```

### Demo

open `tests/index.html`

